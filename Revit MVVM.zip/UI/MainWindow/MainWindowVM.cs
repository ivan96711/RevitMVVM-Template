﻿using Autodesk.Revit.UI;
using $safeprojectname$.RevitAPI.APIClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.UI.MainWindow
{
    public class MainWindowVM
    {
        public string Text { get; set; } = "Hello word";

        public MainWindowVM()
        {

        }
    }
}
